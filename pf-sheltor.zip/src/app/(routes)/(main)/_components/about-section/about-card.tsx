const AboutCard = () => {
  return <div>About Card</div>;
};

export { AboutCard };
